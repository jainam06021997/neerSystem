# regencyRopeBackend

### To install packages run `npm install`

### To run project run `npm start`
